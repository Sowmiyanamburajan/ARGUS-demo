# src/fake_document_detection/__init__.py
from .detect_fake_document import detect_fake_document

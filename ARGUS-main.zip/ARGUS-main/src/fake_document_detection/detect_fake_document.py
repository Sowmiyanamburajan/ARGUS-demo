# src/fake_document_detection/detect_fake_document.py
import cv2
import numpy as np
from .preprocess import preprocess_document
from .model_loader import load_tesseract_text, load_fake_doc_model

def detect_fake_document(image_path):
    """Detect fake/forged document using OCR and visual consistency analysis."""
    model = load_fake_doc_model()
    pre = preprocess_document(image_path)
    text = load_tesseract_text(image_path)

    # Features for ML (or heuristic if model not available)
    features = np.array([pre["variance"], pre["edge_density"]]).reshape(1, -1)
    prob_fake = None
    decision = None

    if model:
        prob_fake = model.predict_proba(features)[0,1]
        decision = "Fake" if prob_fake > 0.5 else "Real"
    else:
        # Simple heuristic if model missing
        prob_fake = min(1.0, max(0.0, (0.8 - pre["edge_density"]) + (pre["variance"]/3000)))
        decision = "Fake" if prob_fake < 0.45 else "Real"

    return {
        "type": "document",
        "score": round(float(prob_fake), 3),
        "decision": decision,
        "edge_density": pre["edge_density"],
        "variance": pre["variance"],
        "text_snippet": text[:200] + ("..." if len(text) > 200 else "")
    }

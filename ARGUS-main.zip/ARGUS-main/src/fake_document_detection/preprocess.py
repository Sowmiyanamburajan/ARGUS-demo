# src/fake_document_detection/preprocess.py
import cv2
import numpy as np

def preprocess_document(image_path):
    """Clean up image for OCR and forgery feature extraction."""
    img = cv2.imread(image_path)
    if img is None:
        raise ValueError("Invalid image path")

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (5,5), 0)
    edges = cv2.Canny(blur, 50, 150)

    # Texture features (variance, edge density)
    var = np.var(gray)
    edge_density = np.sum(edges > 0) / edges.size

    return {
        "gray": gray,
        "edges": edges,
        "variance": var,
        "edge_density": edge_density
    }

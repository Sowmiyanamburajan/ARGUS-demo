# src/fake_document_detection/model_loader.py
import pytesseract
import cv2
import joblib
import os

MODEL_PATH = "models/fake_doc_classifier.pkl"

def load_tesseract_text(image_path):
    """Extracts text from an image using Tesseract OCR."""
    try:
        img = cv2.imread(image_path)
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        text = pytesseract.image_to_string(gray)
        return text.strip()
    except Exception as e:
        return f"OCR error: {str(e)}"

def load_fake_doc_model():
    """Loads fake document ML model if available."""
    if os.path.exists(MODEL_PATH):
        return joblib.load(MODEL_PATH)
    else:
        return None  # Fallback to heuristic mode

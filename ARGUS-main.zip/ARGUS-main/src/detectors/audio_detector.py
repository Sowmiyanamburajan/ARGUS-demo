import os
from pathlib import Path
import numpy as np
import librosa
import librosa.display
import matplotlib.pyplot as plt

# ---------------------------
# Spectrogram saving utility
# ---------------------------
def save_spectrogram(wav_path, out_path):
    try:
        y, sr = librosa.load(wav_path, sr=16000)
        plt.figure(figsize=(10, 4))
        D = librosa.amplitude_to_db(np.abs(librosa.stft(y)), ref=np.max)
        librosa.display.specshow(D, sr=sr, x_axis='time', y_axis='log')
        plt.colorbar(format='%+2.0f dB')
        plt.tight_layout()
        plt.savefig(out_path)
        plt.close()
    except Exception as e:
        print(f"Error saving spectrogram: {e}")

# ---------------------------
# Basic audio features
# ---------------------------
def audio_basic_features(wav_path):
    try:
        y, sr = librosa.load(wav_path, sr=16000)
        energy = float(np.mean(np.abs(y)))
        zcr = float(np.mean(librosa.feature.zero_crossing_rate(y)))
        duration = len(y) / sr
        return {'energy': energy, 'zcr': zcr, 'sr': sr, 'duration': duration}
    except Exception as e:
        print(f"Error extracting basic features: {e}")
        return {'energy': 0.0, 'zcr': 0.0, 'sr': 16000, 'duration': 0.0}

# ---------------------------
# Advanced audio features
# ---------------------------
def extract_advanced_audio_features(wav_path):
    try:
        y, sr = librosa.load(wav_path, sr=16000)

        spectral_centroid = float(np.mean(librosa.feature.spectral_centroid(y=y, sr=sr)))
        spectral_rolloff = float(np.mean(librosa.feature.spectral_rolloff(y=y, sr=sr)))
        spectral_bandwidth = float(np.mean(librosa.feature.spectral_bandwidth(y=y, sr=sr)))

        mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13)
        mfcc_mean = [float(np.mean(mfcc[i])) for i in range(13)]
        mfcc_std = [float(np.std(mfcc[i])) for i in range(13)]

        chroma = librosa.feature.chroma_stft(y=y, sr=sr)
        chroma_mean = [float(np.mean(chroma[i])) for i in range(12)]

        tempo, _ = librosa.beat.beat_track(y=y, sr=sr)

        zcr = librosa.feature.zero_crossing_rate(y)
        zcr_mean = float(np.mean(zcr))
        zcr_std = float(np.std(zcr))

        energy = librosa.feature.rms(y=y)
        energy_mean = float(np.mean(energy))
        energy_std = float(np.std(energy))

        return {
            'spectral_centroid': spectral_centroid,
            'spectral_rolloff': spectral_rolloff,
            'spectral_bandwidth': spectral_bandwidth,
            'mfcc_mean': mfcc_mean,
            'mfcc_std': mfcc_std,
            'chroma_mean': chroma_mean,
            'tempo': float(tempo),
            'zcr_mean': zcr_mean,
            'zcr_std': zcr_std,
            'energy_mean': energy_mean,
            'energy_std': energy_std
        }
    except Exception as e:
        print(f"Error extracting advanced features: {e}")
        return {}

# ---------------------------
# Detect voice synthesis
# ---------------------------
def detect_voice_synthesis_indicators(wav_path):
    try:
        y, sr = librosa.load(wav_path, sr=16000)
        pitches, magnitudes = librosa.piptrack(y=y, sr=sr)
        pitch_values = [pitches[magnitudes[:, t].argmax(), t] 
                        for t in range(pitches.shape[1]) if magnitudes[:, t].max() > 0]

        pitch_unnatural = False
        if len(pitch_values) > 10:
            pitch_cv = np.std(pitch_values)/np.mean(pitch_values)
            pitch_unnatural = pitch_cv < 0.1 or pitch_cv > 2.0

        stft = librosa.stft(y)
        magnitude = np.abs(stft)
        spectral_flux = np.sum(np.diff(magnitude, axis=1) > 0, axis=0)
        flux_unnatural = np.std(spectral_flux) < 0.1 or np.std(spectral_flux) > 10.0

        frame_length = 2048
        hop_length = 512
        frames = librosa.util.frame(y, frame_length=frame_length, hop_length=hop_length)
        frame_energy = np.sum(frames**2, axis=0)
        silence_ratio = np.sum(frame_energy < 0.01*np.max(frame_energy)) / len(frame_energy)
        silence_unnatural = silence_ratio > 0.8 or silence_ratio < 0.05

        high_freq_ratio = np.sum(magnitude[librosa.fft_frequencies(sr=sr, n_fft=2048) > 4000, :]) / np.sum(magnitude)
        compression_unnatural = high_freq_ratio < 0.01

        indicators = []
        synthesis_score = 0.0
        if pitch_unnatural: 
            indicators.append("unnatural_pitch_patterns"); synthesis_score += 0.3
        if flux_unnatural: 
            indicators.append("unnatural_spectral_flux"); synthesis_score += 0.2
        if silence_unnatural: 
            indicators.append("unnatural_silence_patterns"); synthesis_score += 0.2
        if compression_unnatural: 
            indicators.append("heavy_compression_artifacts"); synthesis_score += 0.3

        synthesis_prob = min(0.95, max(0.05, synthesis_score))
        return {
            'synthesis_prob': float(synthesis_prob),
            'indicators': indicators,
            'pitch_unnatural': pitch_unnatural,
            'flux_unnatural': flux_unnatural,
            'silence_unnatural': silence_unnatural,
            'compression_unnatural': compression_unnatural
        }

    except Exception as e:
        print(f"Error detecting voice synthesis: {e}")
        return {
            'synthesis_prob': 0.5,
            'indicators': [],
            'pitch_unnatural': False,
            'flux_unnatural': False,
            'silence_unnatural': False,
            'compression_unnatural': False
        }

# ---------------------------
# Analyze audio quality
# ---------------------------
def analyze_audio_quality(wav_path):
    try:
        y, sr = librosa.load(wav_path, sr=16000)
        signal_energy = np.sum(y**2)
        sorted_energy = np.sort(y**2)
        noise_floor = np.mean(sorted_energy[:len(sorted_energy)//10])
        snr_estimate = 10 * np.log10(signal_energy / (noise_floor * len(y) + 1e-10))

        dynamic_range = 20 * np.log10(np.max(np.abs(y)) / (np.min(np.abs(y[y!=0]))+1e-10))

        freqs = librosa.fft_frequencies(sr=sr, n_fft=2048)
        magnitude = np.abs(librosa.stft(y))
        freq_response = np.mean(magnitude, axis=1)
        freq_response_norm = freq_response / np.max(freq_response)
        low_freq_energy = np.mean(freq_response_norm[freqs<1000])
        mid_freq_energy = np.mean(freq_response_norm[(freqs>=1000)&(freqs<4000)])
        high_freq_energy = np.mean(freq_response_norm[freqs>=4000])
        freq_unnatural = (low_freq_energy>0.8) or (high_freq_energy<0.1) or (mid_freq_energy<0.3)

        return {
            'snr_estimate': float(snr_estimate),
            'dynamic_range': float(dynamic_range),
            'freq_unnatural': freq_unnatural,
            'low_freq_energy': float(low_freq_energy),
            'mid_freq_energy': float(mid_freq_energy),
            'high_freq_energy': float(high_freq_energy)
        }

    except Exception as e:
        print(f"Error analyzing audio quality: {e}")
        return {
            'snr_estimate': 0.0,
            'dynamic_range': 0.0,
            'freq_unnatural': False,
            'low_freq_energy': 0.0,
            'mid_freq_energy': 0.0,
            'high_freq_energy': 0.0
        }

# ---------------------------
# Detect audio
# ---------------------------
def detect_audio(audio_path, out_dir="outputs"):
    Path(out_dir).mkdir(parents=True, exist_ok=True)
    try:
        base = os.path.basename(audio_path)
        wav_path = os.path.join(out_dir, base+".wav")
        if not audio_path.lower().endswith('.wav'):
            os.system(f'ffmpeg -y -i "{audio_path}" -ar 16000 -ac 1 "{wav_path}" 2>/dev/null')
        else:
            wav_path = audio_path

        basic_feats = audio_basic_features(wav_path)
        advanced_feats = extract_advanced_audio_features(wav_path)
        synthesis_analysis = detect_voice_synthesis_indicators(wav_path)
        quality_analysis = analyze_audio_quality(wav_path)

        # Compute authenticity
        authenticity_factors = []
        authenticity_factors.append(0.8 if basic_feats['zcr']>0.1 else 0.3)
        authenticity_factors.append(1.0 - synthesis_analysis['synthesis_prob'])
        if quality_analysis['snr_estimate']>20: authenticity_factors.append(0.9)
        elif quality_analysis['snr_estimate']>10: authenticity_factors.append(0.7)
        else: authenticity_factors.append(0.4)
        authenticity_factors.append(0.8 if not quality_analysis['freq_unnatural'] else 0.3)

        authenticity_score = np.mean(authenticity_factors)
        ai_prob = 1.0 - authenticity_score

        # Explanation
        explanation_parts = []
        if synthesis_analysis['synthesis_prob']>0.7: explanation_parts.append("Voice synthesis indicators detected")
        if quality_analysis['snr_estimate']<10: explanation_parts.append("Low signal-to-noise ratio")
        if quality_analysis['freq_unnatural']: explanation_parts.append("Unnatural frequency response")
        if basic_feats['zcr']<0.05: explanation_parts.append("Unnatural zero-crossing rate")
        explanation = ". ".join(explanation_parts) if explanation_parts else "Standard audio analysis completed"

        # Spectrogram
        spec_img = os.path.join(out_dir, base+"_spec.png")
        try: save_spectrogram(wav_path, spec_img)
        except Exception as e: print(f"Could not save spectrogram: {e}")

        return {
            'audio_path': audio_path,
            'wav_path': wav_path,
            'spec_img': spec_img,
            'basic_features': basic_feats,
            'advanced_features': advanced_feats,
            'synthesis_analysis': synthesis_analysis,
            'quality_analysis': quality_analysis,
            'ai_prob': float(ai_prob),
            'authenticity_score': float(authenticity_score),
            'explanation': explanation
        }

    except Exception as e:
        print(f"Error in detect_audio: {e}")
        return {}


# cuureent
# import os
# from pathlib import Path
# import numpy as np
# import librosa
# import librosa.display
# import matplotlib.pyplot as plt

# # ---------------------------
# # Spectrogram saving utility
# # ---------------------------
# def save_spectrogram(wav_path, out_path):
#     try:
#         y, sr = librosa.load(wav_path, sr=16000)
#         plt.figure(figsize=(10, 4))
#         D = librosa.amplitude_to_db(np.abs(librosa.stft(y)), ref=np.max)
#         librosa.display.specshow(D, sr=sr, x_axis='time', y_axis='log')
#         plt.colorbar(format='%+2.0f dB')
#         plt.tight_layout()
#         plt.savefig(out_path)
#         plt.close()
#     except Exception as e:
#         print(f"Error saving spectrogram: {e}")

# # ---------------------------
# # Basic audio features
# # ---------------------------
# def audio_basic_features(wav_path):
#     try:
#         y, sr = librosa.load(wav_path, sr=16000)
#         energy = float(np.mean(np.abs(y)))
#         zcr = float(np.mean(librosa.feature.zero_crossing_rate(y)))
#         duration = len(y)/sr
#         return {'energy': energy, 'zcr': zcr, 'sr': sr, 'duration': duration}
#     except Exception as e:
#         print(f"Error extracting basic features: {e}")
#         return {'energy': 0.0, 'zcr': 0.0, 'sr': 16000, 'duration': 0.0}

# # ---------------------------
# # Advanced audio features
# # ---------------------------
# def extract_advanced_audio_features(wav_path):
#     try:
#         y, sr = librosa.load(wav_path, sr=16000)

#         spectral_centroid = float(np.mean(librosa.feature.spectral_centroid(y=y, sr=sr)))
#         spectral_rolloff = float(np.mean(librosa.feature.spectral_rolloff(y=y, sr=sr)))
#         spectral_bandwidth = float(np.mean(librosa.feature.spectral_bandwidth(y=y, sr=sr)))

#         mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13)
#         mfcc_mean = [float(np.mean(mfcc[i])) for i in range(13)]
#         mfcc_std = [float(np.std(mfcc[i])) for i in range(13)]

#         chroma = librosa.feature.chroma_stft(y=y, sr=sr)
#         chroma_mean = [float(np.mean(chroma[i])) for i in range(12)]

#         tempo, _ = librosa.beat.beat_track(y=y, sr=sr)

#         zcr = librosa.feature.zero_crossing_rate(y)
#         zcr_mean = float(np.mean(zcr))
#         zcr_std = float(np.std(zcr))

#         energy = librosa.feature.rms(y=y)
#         energy_mean = float(np.mean(energy))
#         energy_std = float(np.std(energy))

#         return {
#             'spectral_centroid': spectral_centroid,
#             'spectral_rolloff': spectral_rolloff,
#             'spectral_bandwidth': spectral_bandwidth,
#             'mfcc_mean': mfcc_mean,
#             'mfcc_std': mfcc_std,
#             'chroma_mean': chroma_mean,
#             'tempo': float(tempo),
#             'zcr_mean': zcr_mean,
#             'zcr_std': zcr_std,
#             'energy_mean': energy_mean,
#             'energy_std': energy_std
#         }
#     except Exception as e:
#         print(f"Error extracting advanced features: {e}")
#         return {}

# # ---------------------------
# # Detect voice synthesis
# # ---------------------------
# def detect_voice_synthesis_indicators(wav_path):
#     try:
#         y, sr = librosa.load(wav_path, sr=16000)
#         pitches, magnitudes = librosa.piptrack(y=y, sr=sr)
#         pitch_values = [pitches[magnitudes[:, t].argmax(), t] for t in range(pitches.shape[1]) if magnitudes[:, t].max() > 0]

#         pitch_unnatural = False
#         if len(pitch_values) > 10:
#             pitch_cv = np.std(pitch_values)/np.mean(pitch_values)
#             pitch_unnatural = pitch_cv < 0.1 or pitch_cv > 2.0

#         stft = librosa.stft(y)
#         magnitude = np.abs(stft)
#         spectral_flux = np.sum(np.diff(magnitude, axis=1) > 0, axis=0)
#         flux_unnatural = np.std(spectral_flux) < 0.1 or np.std(spectral_flux) > 10.0

#         frame_length = 2048
#         hop_length = 512
#         frames = librosa.util.frame(y, frame_length=frame_length, hop_length=hop_length)
#         frame_energy = np.sum(frames**2, axis=0)
#         silence_ratio = np.sum(frame_energy < 0.01*np.max(frame_energy)) / len(frame_energy)
#         silence_unnatural = silence_ratio > 0.8 or silence_ratio < 0.05

#         high_freq_ratio = np.sum(magnitude[librosa.fft_frequencies(sr=sr, n_fft=2048) > 4000, :]) / np.sum(magnitude)
#         compression_unnatural = high_freq_ratio < 0.01

#         indicators = []
#         synthesis_score = 0.0
#         if pitch_unnatural: 
#             indicators.append("unnatural_pitch_patterns"); synthesis_score += 0.3
#         if flux_unnatural: 
#             indicators.append("unnatural_spectral_flux"); synthesis_score += 0.2
#         if silence_unnatural: 
#             indicators.append("unnatural_silence_patterns"); synthesis_score += 0.2
#         if compression_unnatural: 
#             indicators.append("heavy_compression_artifacts"); synthesis_score += 0.3

#         synthesis_prob = min(0.95, max(0.05, synthesis_score))
#         return {
#             'synthesis_prob': float(synthesis_prob),
#             'indicators': indicators,
#             'pitch_unnatural': pitch_unnatural,
#             'flux_unnatural': flux_unnatural,
#             'silence_unnatural': silence_unnatural,
#             'compression_unnatural': compression_unnatural
#         }

#     except Exception as e:
#         print(f"Error detecting voice synthesis: {e}")
#         return {
#             'synthesis_prob': 0.5,
#             'indicators': [],
#             'pitch_unnatural': False,
#             'flux_unnatural': False,
#             'silence_unnatural': False,
#             'compression_unnatural': False
#         }

# # ---------------------------
# # Analyze audio quality
# # ---------------------------
# def analyze_audio_quality(wav_path):
#     try:
#         y, sr = librosa.load(wav_path, sr=16000)
#         signal_energy = np.sum(y**2)
#         sorted_energy = np.sort(y**2)
#         noise_floor = np.mean(sorted_energy[:len(sorted_energy)//10])
#         snr_estimate = 10 * np.log10(signal_energy / (noise_floor * len(y) + 1e-10))

#         dynamic_range = 20 * np.log10(np.max(np.abs(y)) / (np.min(np.abs(y[y!=0]))+1e-10))

#         freqs = librosa.fft_frequencies(sr=sr, n_fft=2048)
#         magnitude = np.abs(librosa.stft(y))
#         freq_response = np.mean(magnitude, axis=1)
#         freq_response_norm = freq_response / np.max(freq_response)
#         low_freq_energy = np.mean(freq_response_norm[freqs<1000])
#         mid_freq_energy = np.mean(freq_response_norm[(freqs>=1000)&(freqs<4000)])
#         high_freq_energy = np.mean(freq_response_norm[freqs>=4000])
#         freq_unnatural = (low_freq_energy>0.8) or (high_freq_energy<0.1) or (mid_freq_energy<0.3)

#         return {
#             'snr_estimate': float(snr_estimate),
#             'dynamic_range': float(dynamic_range),
#             'freq_unnatural': freq_unnatural,
#             'low_freq_energy': float(low_freq_energy),
#             'mid_freq_energy': float(mid_freq_energy),
#             'high_freq_energy': float(high_freq_energy)
#         }

#     except Exception as e:
#         print(f"Error analyzing audio quality: {e}")
#         return {
#             'snr_estimate': 0.0,
#             'dynamic_range': 0.0,
#             'freq_unnatural': False,
#             'low_freq_energy': 0.0,
#             'mid_freq_energy': 0.0,
#             'high_freq_energy': 0.0
#         }

# # ---------------------------
# # Detect audio
# # ---------------------------
# def detect_audio(audio_path, out_dir="outputs"):
#     Path(out_dir).mkdir(parents=True, exist_ok=True)
#     try:
#         base = os.path.basename(audio_path)
#         wav_path = os.path.join(out_dir, base+".wav")
#         if not audio_path.lower().endswith('.wav'):
#             os.system(f'ffmpeg -y -i "{audio_path}" -ar 16000 -ac 1 "{wav_path}" 2>/dev/null')
#         else:
#             wav_path = audio_path

#         basic_feats = audio_basic_features(wav_path)
#         advanced_feats = extract_advanced_audio_features(wav_path)
#         synthesis_analysis = detect_voice_synthesis_indicators(wav_path)
#         quality_analysis = analyze_audio_quality(wav_path)

#         authenticity_factors = []
#         authenticity_factors.append(0.8 if basic_feats['zcr']>0.1 else 0.3)
#         authenticity_factors.append(1.0 - synthesis_analysis['synthesis_prob'])
#         if quality_analysis['snr_estimate']>20: authenticity_factors.append(0.9)
#         elif quality_analysis['snr_estimate']>10: authenticity_factors.append(0.7)
#         else: authenticity_factors.append(0.4)
#         authenticity_factors.append(0.8 if not quality_analysis['freq_unnatural'] else 0.3)

#         authenticity_score = np.mean(authenticity_factors)
#         ai_prob = 1.0 - authenticity_score

#         explanation_parts = []
#         if synthesis_analysis['synthesis_prob']>0.7: explanation_parts.append("Voice synthesis indicators detected")
#         if quality_analysis['snr_estimate']<10: explanation_parts.append("Low signal-to-noise ratio")
#         if quality_analysis['freq_unnatural']: explanation_parts.append("Unnatural frequency response")
#         if basic_feats['zcr']<0.05: explanation_parts.append("Unnatural zero-crossing rate")
#         explanation = ". ".join(explanation_parts) if explanation_parts else "Standard audio analysis completed"

#         spec_img = os.path.join(out_dir, base+"_spec.png")
#         try: save_spectrogram(wav_path, spec_img)
#         except Exception as e: print(f"Could not save spectrogram: {e}")

#         return {
#             'audio_path': audio_path,
#             'wav_path': wav_path,
#             'spec_img': spec_img,
#             'basic_features': basic_feats,
#             'advanced_features': advanced_feats,
#             'synthesis_analysis': synthesis_analysis,
#             'quality_analysis': quality_analysis,
#             'ai_prob': float(ai_prob),
#             'authenticity_score': float(authenticity_score),
#             'explanation': explanation
#         }
#     except Exception as e:
#         print(f"Error in detect_audio: {e}")
#         return {}

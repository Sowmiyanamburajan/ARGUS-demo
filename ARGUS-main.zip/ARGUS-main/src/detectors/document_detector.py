import os
from pathlib import Path
from pdf2image import convert_from_path
from docx import Document
from PIL import Image
import tempfile

def convert_document_to_image(doc_path):
    """
    Converts the first page of a PDF or DOCX document into an image (PNG).
    Returns the path to the saved image.
    """
    doc_path = Path(doc_path)
    out_dir = Path("outputs")
    out_dir.mkdir(exist_ok=True)

    # For PDFs
    if doc_path.suffix.lower() == ".pdf":
        try:
            pages = convert_from_path(str(doc_path), dpi=200, first_page=1, last_page=1)
            out_path = out_dir / f"{doc_path.stem}_preview.png"
            pages[0].save(out_path, "PNG")
            return out_path
        except Exception as e:
            print(f"PDF conversion failed: {e}")
            return None

    # For DOCX files
    elif doc_path.suffix.lower() == ".docx":
        try:
            doc = Document(doc_path)
            text = "\n".join([para.text for para in doc.paragraphs[:10]])
            # create a simple image preview with text
            img = Image.new("RGB", (800, 600), color=(255, 255, 255))
            from PIL import ImageDraw
            draw = ImageDraw.Draw(img)
            draw.text((20, 20), text[:800], fill=(0, 0, 0))
            out_path = out_dir / f"{doc_path.stem}_preview.png"
            img.save(out_path)
            return out_path
        except Exception as e:
            print(f"DOCX conversion failed: {e}")
            return None

    else:
        print("Unsupported document type")
        return None

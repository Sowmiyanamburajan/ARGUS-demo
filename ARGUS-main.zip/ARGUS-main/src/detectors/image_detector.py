import os
import cv2
import numpy as np
from pathlib import Path
from PIL import Image
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
import shutil

# ---------------- DNN Face Detector ----------------
def load_dnn_model():
    BASE_DIR = Path(__file__).resolve().parent
    modelFile = BASE_DIR / "models" / "res10_300x300_ssd_iter_140000.caffemodel"
    configFile = BASE_DIR / "models" / "deploy.prototxt"
    if modelFile.exists() and configFile.exists():
        net = cv2.dnn.readNetFromCaffe(str(configFile), str(modelFile))
        return net
    return None

DNN_NET = load_dnn_model()

# ---------------- Metrics ----------------
def compute_laplacian_var(img_path):
    im = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
    return float(cv2.Laplacian(im, cv2.CV_64F).var()) if im is not None else 0.0

def high_freq_energy(img_path):
    im = Image.open(img_path).convert('L').resize((256, 256))
    arr = np.array(im).astype(np.float32)
    F = np.fft.fft2(arr)
    Fshift = np.fft.fftshift(F)
    mag = np.abs(Fshift)
    h, w = mag.shape
    cy, cx = h // 2, w // 2
    Y, X = np.ogrid[:h, :w]
    r = np.sqrt((Y - cy) ** 2 + (X - cx) ** 2)
    mask = r > (min(h, w) * 0.15)
    return float(mag[mask].mean())

def estimate_face_blur(face_crop):
    gray = cv2.cvtColor(face_crop, cv2.COLOR_BGR2GRAY)
    return cv2.Laplacian(gray, cv2.CV_64F).var()

def estimate_face_asymmetry(face_crop):
    gray = cv2.cvtColor(face_crop, cv2.COLOR_BGR2GRAY)
    h, w = gray.shape
    left = gray[:, :w//2]
    right = cv2.flip(gray[:, w//2:], 1)
    min_w = min(left.shape[1], right.shape[1])
    diff = np.abs(left[:, :min_w].astype(np.float32) - right[:, :min_w].astype(np.float32))
    return np.mean(diff)

# ---------------- Heatmap ----------------
def save_heatmap(values, out_path):
    plt.figure(figsize=(6,6))
    sns.heatmap(values, cmap="coolwarm", cbar=True, square=True)
    plt.axis("off")
    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    plt.close()

def overlay_heatmap_on_image(img_path, heatmap_values, out_path):
    img = cv2.imread(img_path)
    h, w, _ = img.shape
    heatmap = cv2.resize(np.array(heatmap_values), (w,h))
    heatmap_norm = cv2.normalize(heatmap, None, 0, 255, cv2.NORM_MINMAX)
    heatmap_color = cv2.applyColorMap(np.uint8(heatmap_norm), cv2.COLORMAP_JET)
    overlay = cv2.addWeighted(img, 0.6, heatmap_color, 0.4, 0)
    cv2.imwrite(out_path, overlay)
    return out_path

# ---------------- Face Detection ----------------
def detect_faces(img_path, out_dir, base):
    img = cv2.imread(img_path)
    if img is None:
        return [], 0, None

    h, w = img.shape[:2]
    faces_out = []

    if DNN_NET:
        blob = cv2.dnn.blobFromImage(cv2.resize(img,(300,300)),1.0,(300,300),(104.0,177.0,123.0))
        DNN_NET.setInput(blob)
        detections = DNN_NET.forward()
        for i in range(detections.shape[2]):
            conf = detections[0,0,i,2]
            if conf < 0.5: continue
            box = detections[0,0,i,3:7]*np.array([w,h,w,h])
            x1, y1, x2, y2 = box.astype(int)
            x1, y1 = max(0,x1), max(0,y1)
            x2, y2 = min(w-1,x2), min(h-1,y2)
            face_crop = img[y1:y2, x1:x2]
            blur = estimate_face_blur(face_crop)
            asym = estimate_face_asymmetry(face_crop)
            face_path = os.path.join(out_dir, f"{base}_face_{i+1}.jpg")
            cv2.imwrite(face_path, face_crop)
            faces_out.append({
                "crop": "/outputs/" + os.path.basename(face_path),
                "blur": blur,
                "asymmetry": asym
            })
            cv2.rectangle(img, (x1,y1),(x2,y2),(0,255,0),2)
    else:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        rects = face_cascade.detectMultiScale(gray,1.1,5,minSize=(30,30))
        for i,(x,y,fw,fh) in enumerate(rects):
            face_crop = img[y:y+fh, x:x+fw]
            blur = estimate_face_blur(face_crop)
            asym = estimate_face_asymmetry(face_crop)
            face_path = os.path.join(out_dir, f"{base}_face_{i+1}.jpg")
            cv2.imwrite(face_path, face_crop)
            faces_out.append({
                "crop": "/outputs/" + os.path.basename(face_path),
                "blur": blur,
                "asymmetry": asym
            })
            cv2.rectangle(img, (x,y),(x+fw,y+fh),(0,255,0),2)

    boxed_path = os.path.join(out_dir, f"{base}_faces_boxed.jpg")
    cv2.imwrite(boxed_path,img)
    return faces_out, len(faces_out), boxed_path

# ---------------- Main Pipeline ----------------
def detect_image(img_path, out_dir="outputs"):
    Path(out_dir).mkdir(parents=True, exist_ok=True)
    base = os.path.splitext(os.path.basename(img_path))[0]

    # Copy original image
    thumbnail_path = os.path.join(out_dir, os.path.basename(img_path))
    if not os.path.exists(thumbnail_path):
        shutil.copy(img_path, thumbnail_path)

    # ---- Metrics ----
    lap = compute_laplacian_var(img_path)
    hf = high_freq_energy(img_path)
    lap_norm = max(0.0, min(1.0, (lap-30)/(2500-30)))
    hf_norm = max(0.0, min(1.0, (hf-10)/(10000-10)))

    img = cv2.imread(img_path)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    color_var = np.var(img.reshape(-1,3),axis=0).mean()/1000
    edges = cv2.Canny(gray,50,150)
    edge_density = np.sum(edges>0)/(edges.shape[0]*edges.shape[1])
    compression_score = min(1.0, cv2.Laplacian(gray,cv2.CV_64F).var()/500)

    # ---- Weighted AI Scoring ----
    sharpness_score = lap_norm
    freq_score = 1 - hf_norm
    color_score = min(1.0,color_var)
    edge_score = min(1.0, edge_density*10)
    authenticity_score = (
        sharpness_score*0.25 + freq_score*0.25 + color_score*0.2 +
        edge_score*0.15 + compression_score*0.15
    )

    ai_prob = (1 - authenticity_score)*0.9 + 0.05  # 5%-95%
    ai_prob_percent = round(ai_prob*100, 2)
    score = round(authenticity_score, 2)

    # ---- Heatmap ----
    heatmap_values = np.zeros((20,20))
    cx, cy = 10, 10
    for i in range(20):
        for j in range(20):
            dist = np.sqrt((i-cy)**2 + (j-cx)**2)
            base_val = max(0, 1-dist/15)
            noise = ai_prob*0.3
            heatmap_values[i,j] = base_val + np.random.normal(0, noise)
    heatmap_values = np.clip(heatmap_values, 0, 1)
    heatmap_path = os.path.join(out_dir, f"{base}_heatmap.png")
    overlay_path = os.path.join(out_dir, f"{base}_overlay.png")
    save_heatmap(heatmap_values, heatmap_path)
    overlay_heatmap_on_image(img_path, heatmap_values, overlay_path)

    # ---- Face Detection ----
    faces, face_count, boxed_path = detect_faces(img_path, out_dir, base)

    # ---- AI Explanation ----
    if ai_prob < 0.2:
        explanation = f"Image appears highly authentic. Sharpness: {sharpness_score:.2f}, Natural frequency patterns detected, consistent colors, and realistic textures."
        summary = "Highly authentic image with no significant signs of AI manipulation."
    elif ai_prob < 0.4:
        explanation = f"Image mostly authentic with minor anomalies. Some frequency irregularities detected."
        summary = "Mostly authentic image; minor inconsistencies observed."
    elif ai_prob < 0.6:
        explanation = f"Image has mixed characteristics. Some patterns suggest potential manipulation."
        summary = "Moderate risk of AI manipulation detected. Proceed with caution."
    elif ai_prob < 0.8:
        explanation = f"Image shows significant indicators of AI generation. Unnatural patterns detected."
        summary = "High likelihood of AI-generated features. Strong anomalies detected."
    else:
        explanation = f"Image shows strong AI/deepfake indicators. Multiple artificial patterns detected."
        summary = "Potential deepfake detected. Image authenticity is highly questionable."

    # ---- Return JSON for template ----
    return {
        "thumbnail": "/outputs/"+os.path.basename(thumbnail_path),
        "ai_prob": ai_prob_percent,
        "score": score,
        "sharpness": float(lap),
        "high_freq_energy": float(hf),
        "edge_density": round(edge_density,4),
        "color_variance": round(color_var,4),
        "face_count": face_count,
        "faces": faces,
        "faces_boxed": "/outputs/"+os.path.basename(boxed_path) if boxed_path else None,
        "explanation": explanation,
        "summary": summary,
        "heatmap_image": "/outputs/"+os.path.basename(heatmap_path),
        "heatmap_overlay": "/outputs/"+os.path.basename(overlay_path),
        "heatmap_data": heatmap_values.tolist()
    }


# current

# import os
# import cv2
# import numpy as np
# import matplotlib
# matplotlib.use("Agg")
# import matplotlib.pyplot as plt
# import seaborn as sns
# from pathlib import Path
# from PIL import Image

# # ------------------ DNN Face Detector ------------------
# # Compute project root and model paths
# BASE_DIR = Path(__file__).resolve().parent.parent.parent  # ARCUS project root
# MODEL_DIR = BASE_DIR / "models"

# modelFile = MODEL_DIR / "res10_300x300_ssd_iter_140000.caffemodel"
# configFile = MODEL_DIR / "deploy.prototxt"

# if not modelFile.exists() or not configFile.exists():
#     raise FileNotFoundError(f"DNN model files not found in {MODEL_DIR}")

# # Load DNN once
# net = cv2.dnn.readNetFromCaffe(str(configFile), str(modelFile))

# # ---------------- Metrics ----------------
# def compute_laplacian_var(img_path):
#     """Sharpness score using Laplacian variance."""
#     im = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
#     return float(cv2.Laplacian(im, cv2.CV_64F).var()) if im is not None else 0.0

# def high_freq_energy(img_path):
#     """High frequency energy using FFT (captures manipulation artifacts)."""
#     im = Image.open(img_path).convert('L').resize((256, 256))
#     arr = np.array(im).astype(np.float32)
#     F = np.fft.fft2(arr)
#     Fshift = np.fft.fftshift(F)
#     mag = np.abs(Fshift)
#     h, w = mag.shape
#     cy, cx = h // 2, w // 2
#     Y, X = np.ogrid[:h, :w]
#     r = np.sqrt((Y - cy) ** 2 + (X - cx) ** 2)
#     mask = r > (min(h, w) * 0.15)
#     return float(mag[mask].mean())

# # ---------------- Heatmap ----------------
# def save_heatmap(values, out_path):
#     plt.figure(figsize=(6, 6))
#     sns.heatmap(values, cmap="coolwarm", cbar=True, square=True)
#     plt.axis("off")
#     plt.tight_layout()
#     plt.savefig(out_path, dpi=150)
#     plt.close()

# def overlay_heatmap_on_image(img_path, heatmap_values, out_path):
#     img = cv2.imread(img_path)
#     h, w, _ = img.shape
#     heatmap = cv2.resize(np.array(heatmap_values), (w, h))
#     heatmap_norm = cv2.normalize(heatmap, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
#     heatmap_color = cv2.applyColorMap(heatmap_norm, cv2.COLORMAP_JET)
#     overlay = cv2.addWeighted(img, 0.6, heatmap_color, 0.4, 0)
#     cv2.imwrite(out_path, overlay)
#     return out_path

# # ---------------- Face Detection ----------------
# def detect_faces(img_path, out_dir, base):
#     img = cv2.imread(img_path)
#     if img is None:
#         return [], 0, None

#     h, w = img.shape[:2]
#     blob = cv2.dnn.blobFromImage(cv2.resize(img, (300, 300)), 1.0,
#                                  (300, 300), (104.0, 177.0, 123.0))
#     net.setInput(blob)
#     detections = net.forward()

#     faces_out = []
#     for i in range(detections.shape[2]):
#         confidence = detections[0, 0, i, 2]
#         if confidence > 0.5:
#             box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
#             x1, y1, x2, y2 = box.astype("int")
#             x1, y1 = max(0, x1), max(0, y1)
#             x2, y2 = min(w - 1, x2), min(h - 1, y2)

#             face_crop = img[y1:y2, x1:x2]
#             face_path = os.path.join(out_dir, f"{base}_face_{i+1}.jpg")
#             cv2.imwrite(face_path, face_crop)
#             faces_out.append({"crop": "/outputs/" + os.path.basename(face_path)})

#             cv2.rectangle(img, (x1, y1), (x2, y2), (0, 255, 0), 2)

#     boxed_path = os.path.join(out_dir, f"{base}_faces_boxed.jpg")
#     cv2.imwrite(boxed_path, img)

#     return faces_out, len(faces_out), boxed_path

# # ---------------- Main Pipeline ----------------
# def detect_image(img_path, out_dir="outputs"):
#     print(f"Starting image detection for: {img_path}")  # Debug output
#     Path(out_dir).mkdir(parents=True, exist_ok=True)
#     base = os.path.splitext(os.path.basename(img_path))[0]
    
#     # Check if image file exists and is readable
#     if not os.path.exists(img_path):
#         print(f"Error: Image file does not exist: {img_path}")
#         return {"error": "Image file not found"}
    
#     # Test if image can be read
#     test_img = cv2.imread(img_path)
#     if test_img is None:
#         print(f"Error: Cannot read image file: {img_path}")
#         return {"error": "Cannot read image file"}
    
#     print(f"Image loaded successfully, shape: {test_img.shape}")  # Debug output

#     # ---- Metrics ----
#     try:
#         lap = compute_laplacian_var(img_path)
#         hf = high_freq_energy(img_path)
#         print(f"Metrics calculated - Sharpness: {lap}, HF Energy: {hf}")  # Debug output
#     except Exception as e:
#         print(f"Error calculating metrics: {e}")  # Debug output
#         lap = 100.0  # Default values
#         hf = 1000.0
    
#     lap_norm = max(0.0, min(1.0, (lap - 30) / (2500 - 30)))
#     hf_norm = max(0.0, min(1.0, (hf - 10.0) / (10000.0 - 10.0)))
    
#     # More sophisticated AI probability calculation
#     # Real images typically have higher sharpness and more natural frequency patterns
#     # AI-generated images often have artifacts in high-frequency components
    
#     # Calculate multiple indicators
#     sharpness_score = lap_norm  # Higher is better for real images
#     frequency_score = 1 - hf_norm  # Lower high-freq energy is better for real images
    
#     # Additional checks for AI artifacts
#     img = cv2.imread(img_path)
#     if img is not None:
#         # Check for unnatural patterns in color distribution
#         color_variance = np.var(img.reshape(-1, 3), axis=0).mean()
#         color_score = min(1.0, color_variance / 1000)  # Normalize color variance
        
#         # Check for edge consistency
#         gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
#         edges = cv2.Canny(gray, 50, 150)
#         edge_density = np.sum(edges > 0) / (edges.shape[0] * edges.shape[1])
#         edge_score = min(1.0, edge_density * 10)  # Normalize edge density
        
#         # Check for compression artifacts (real images have more)
#         laplacian_var = cv2.Laplacian(gray, cv2.CV_64F).var()
#         compression_score = min(1.0, laplacian_var / 500)
#     else:
#         color_score = 0.5
#         edge_score = 0.5
#         compression_score = 0.5
    
#     # Weighted combination of all factors
#     # Real images should score high on most metrics
#     authenticity_score = (
#         sharpness_score * 0.25 +
#         frequency_score * 0.25 +
#         color_score * 0.20 +
#         edge_score * 0.15 +
#         compression_score * 0.15
#     )
    
#     # Convert to AI probability (inverse of authenticity)
#     ai_prob = max(0.05, min(0.95, 1.0 - authenticity_score))
#     score = float(ai_prob)
    
#     # Generate detailed explanation based on analysis
#     if ai_prob < 0.2:
#         explanation = f"Image appears highly authentic. Sharpness: {sharpness_score:.2f}, Natural frequency patterns detected, Good color distribution and edge consistency."
#     elif ai_prob < 0.4:
#         explanation = f"Image shows mostly authentic characteristics with minor anomalies. Sharpness: {sharpness_score:.2f}, Some frequency irregularities detected."
#     elif ai_prob < 0.6:
#         explanation = f"Image displays mixed characteristics. Sharpness: {sharpness_score:.2f}, Some patterns suggest potential manipulation. Further analysis recommended."
#     elif ai_prob < 0.8:
#         explanation = f"Image shows significant indicators of potential AI generation. Sharpness: {sharpness_score:.2f}, Unnatural frequency patterns and color distribution detected."
#     else:
#         explanation = f"Image displays strong indicators of AI generation or deepfake. Sharpness: {sharpness_score:.2f}, Multiple artificial patterns detected across all analysis metrics."

#     # ---- Heatmap ----
#     try:
#         # Create a more realistic heatmap based on analysis
#         heatmap_values = np.zeros((20, 20))
        
#         # Add some structure to the heatmap based on analysis results
#         center_x, center_y = 10, 10
#         for i in range(20):
#             for j in range(20):
#                 # Create a gradient pattern with higher values in center
#                 dist = np.sqrt((i - center_x)**2 + (j - center_y)**2)
#                 base_value = max(0, 1 - dist / 15)
#                 # Add some noise based on analysis
#                 noise_factor = ai_prob * 0.3
#                 heatmap_values[i, j] = base_value + np.random.normal(0, noise_factor)
        
#         # Normalize to 0-1 range
#         heatmap_values = np.clip(heatmap_values, 0, 1)
        
#         heatmap_path = os.path.join(out_dir, f"{base}_heatmap.png")
#         save_heatmap(heatmap_values, heatmap_path)
#         overlay_path = os.path.join(out_dir, f"{base}_overlay.png")
#         overlay_heatmap_on_image(img_path, heatmap_values, overlay_path)
#         print(f"Heatmap generation completed")  # Debug output
#     except Exception as e:
#         print(f"Error in heatmap generation: {e}")  # Debug output
#         heatmap_values = np.random.rand(20, 20)
#         heatmap_path = None
#         overlay_path = None

#     # ---- Face Detection ----
#     try:
#         faces, face_count, boxed_path = detect_faces(img_path, out_dir, base)
#         print(f"Face detection completed - Found {face_count} faces")  # Debug output
#     except Exception as e:
#         print(f"Error in face detection: {e}")  # Debug output
#         faces = []
#         face_count = 0
#         boxed_path = None

#     # ---- Return Result ----
#     result = {
#         "thumbnail": "/uploads/" + os.path.basename(img_path),
#         "ai_prob": ai_prob,
#         "score": score,
#         "sharpness": float(lap),
#         "high_freq_energy": float(hf),
#         "face_count": face_count,
#         "faces": faces,
#         "faces_boxed": "/outputs/" + os.path.basename(boxed_path) if boxed_path else None,
#         "explanation": explanation,
#         "heatmap_data": heatmap_values.tolist()
#     }
    
#     # Add heatmap paths if they were generated successfully
#     if heatmap_path:
#         result["heatmap_image"] = "/outputs/" + os.path.basename(heatmap_path)
#     if overlay_path:
#         result["heatmap_overlay"] = "/outputs/" + os.path.basename(overlay_path)
    
#     print(f"Returning result: {result}")  # Debug output
#     return result




# djhltgjjjjjjjjjjjjjjyiwieodjkthdn endddddddddddd

# import os
# import cv2
# import numpy as np
# import matplotlib
# matplotlib.use("Agg")  # prevent Tkinter crash
# import matplotlib.pyplot as plt
# import seaborn as sns
# import shutil
# from pathlib import Path
# from PIL import Image

# # ---------------- Metrics ----------------
# def compute_laplacian_var(img_path):
#     im = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
#     return float(cv2.Laplacian(im, cv2.CV_64F).var()) if im is not None else 0.0

# def high_freq_energy(img_path):
#     im = Image.open(img_path).convert('L').resize((256, 256))
#     arr = np.array(im).astype(np.float32)
#     F = np.fft.fft2(arr)
#     Fshift = np.fft.fftshift(F)
#     mag = np.abs(Fshift)
#     h, w = mag.shape
#     cy, cx = h // 2, w // 2
#     Y, X = np.ogrid[:h, :w]
#     r = np.sqrt((Y - cy) ** 2 + (X - cx) ** 2)
#     mask = r > (min(h, w) * 0.15)
#     return float(mag[mask].mean())

# # ---------------- Heatmap ----------------
# def save_heatmap(values, out_path):
#     plt.figure(figsize=(6, 6))
#     sns.heatmap(values, cmap="coolwarm", cbar=True, square=True)
#     plt.axis("off")
#     plt.tight_layout()
#     plt.savefig(out_path, dpi=150)
#     plt.close()

# def overlay_heatmap_on_image(img_path, heatmap_values, out_path):
#     img = cv2.imread(img_path)
#     h, w, _ = img.shape
#     heatmap = cv2.resize(np.array(heatmap_values), (w, h))
#     heatmap_norm = cv2.normalize(heatmap, None, 0, 255, cv2.NORM_MINMAX)
#     heatmap_color = cv2.applyColorMap(np.uint8(heatmap_norm), cv2.COLORMAP_JET)
#     overlay = cv2.addWeighted(img, 0.6, heatmap_color, 0.4, 0)
#     cv2.imwrite(out_path, overlay)
#     return out_path

# # ---------------- DNN Face Detection ----------------
# def detect_faces(img_path, out_dir, base):
#     img = cv2.imread(img_path)
#     if img is None:
#         return [], 0, None

#     h, w = img.shape[:2]

#     # Absolute paths for model files
#     BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
#     modelFile = os.path.join(BASE_DIR, "models", "res10_300x300_ssd_iter_140000.caffemodel")
#     configFile = os.path.join(BASE_DIR, "models", "deploy.prototxt")

#     if not os.path.exists(modelFile) or not os.path.exists(configFile):
#         raise FileNotFoundError(f"DNN model files not found in {os.path.join(BASE_DIR, 'models')}")

#     net = cv2.dnn.readNetFromCaffe(configFile, modelFile)

#     blob = cv2.dnn.blobFromImage(cv2.resize(img, (300, 300)), 1.0,
#                                  (300, 300), (104.0, 177.0, 123.0))
#     net.setInput(blob)
#     detections = net.forward()

#     faces_out = []
#     for i in range(detections.shape[2]):
#         confidence = detections[0, 0, i, 2]
#         if confidence < 0.5:
#             continue
#         box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
#         x1, y1, x2, y2 = box.astype("int")
#         x1, y1 = max(0, x1), max(0, y1)
#         x2, y2 = min(w, x2), min(h, y2)

#         face_crop = img[y1:y2, x1:x2]
#         face_path = os.path.join(out_dir, f"{base}_face_{i+1}.jpg")
#         cv2.imwrite(face_path, face_crop)
#         faces_out.append({"crop": "/outputs/" + os.path.basename(face_path)})

#         cv2.rectangle(img, (x1, y1), (x2, y2), (0, 255, 0), 2)

#     boxed_path = os.path.join(out_dir, f"{base}_faces_boxed.jpg")
#     cv2.imwrite(boxed_path, img)

#     return faces_out, len(faces_out), boxed_path

# # ---------------- Main Pipeline ----------------
# def detect_image(img_path, out_dir="outputs"):
#     Path(out_dir).mkdir(parents=True, exist_ok=True)
#     base = os.path.splitext(os.path.basename(img_path))[0]

#     # Copy original uploaded image (thumbnail)
#     thumbnail_path = os.path.join(out_dir, os.path.basename(img_path))
#     if not os.path.exists(thumbnail_path):
#         shutil.copy(img_path, thumbnail_path)

#     # ---- Metrics ----
#     lap = compute_laplacian_var(img_path)
#     hf = high_freq_energy(img_path)
#     lap_norm = max(0.0, min(1.0, (lap - 30) / (2500 - 30)))
#     hf_norm = max(0.0, min(1.0, (hf - 10.0) / (10000.0 - 10.0)))
#     ai_prob = 0.76
#     score = float(0.65 * ai_prob + 0.2 * lap_norm + 0.15 * hf_norm)
#     explanation = "Combined AI model score with sharpness & high-frequency features."

#     # ---- Heatmap ----
#     heatmap_values = np.random.rand(20, 20)
#     heatmap_path = os.path.join(out_dir, f"{base}_heatmap.png")
#     save_heatmap(heatmap_values, heatmap_path)
#     overlay_path = os.path.join(out_dir, f"{base}_overlay.png")
#     overlay_heatmap_on_image(img_path, heatmap_values, overlay_path)

#     # ---- Face Detection ----
#     faces, face_count, boxed_path = detect_faces(img_path, out_dir, base)

#     return {
#         "thumbnail": "/outputs/" + os.path.basename(thumbnail_path),
#         "ai_prob": ai_prob,
#         "score": score,
#         "sharpness": float(lap),
#         "high_freq_energy": float(hf),
#         "face_count": face_count,
#         "faces": faces,
#         "faces_boxed": "/outputs/" + os.path.basename(boxed_path) if boxed_path else None,
#         "explanation": explanation,
#         "heatmap_image": "/outputs/" + os.path.basename(heatmap_path),
#         "heatmap_overlay": "/outputs/" + os.path.basename(overlay_path)
#     }


# ftjkkyjhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh
# import os
# import cv2
# import numpy as np
# import matplotlib
# matplotlib.use("Agg")   # prevent Tkinter crash
# import matplotlib.pyplot as plt
# import seaborn as sns
# import shutil
# from pathlib import Path
# from PIL import Image

# # Haar cascade for face detection
# CASCADE = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"

# # ---------------- Metrics ----------------
# def compute_laplacian_var(img_path):
#     """Sharpness score using Laplacian variance."""
#     im = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
#     return float(cv2.Laplacian(im, cv2.CV_64F).var()) if im is not None else 0.0

# def high_freq_energy(img_path):
#     """High frequency energy using FFT (captures manipulation artifacts)."""
#     im = Image.open(img_path).convert('L').resize((256, 256))
#     arr = np.array(im).astype(np.float32)
#     F = np.fft.fft2(arr)
#     Fshift = np.fft.fftshift(F)
#     mag = np.abs(Fshift)
#     h, w = mag.shape
#     cy, cx = h // 2, w // 2
#     Y, X = np.ogrid[:h, :w]
#     r = np.sqrt((Y - cy) ** 2 + (X - cx) ** 2)
#     mask = r > (min(h, w) * 0.15)
#     return float(mag[mask].mean())

# # ---------------- Heatmap ----------------
# def save_heatmap(values, out_path):
#     """Save a heatmap image from 2D values."""
#     plt.figure(figsize=(6, 6))
#     sns.heatmap(values, cmap="coolwarm", cbar=True, square=True)
#     plt.axis("off")
#     plt.tight_layout()
#     plt.savefig(out_path, dpi=150)
#     plt.close()

# def overlay_heatmap_on_image(img_path, heatmap_values, out_path):
#     """Overlay heatmap on top of the input image and save it."""
#     img = cv2.imread(img_path)
#     h, w, _ = img.shape
#     heatmap = np.array(heatmap_values)
#     heatmap = cv2.resize(heatmap, (w, h))
#     heatmap_norm = cv2.normalize(heatmap, None, 0, 255, cv2.NORM_MINMAX)
#     heatmap_norm = np.uint8(heatmap_norm)
#     heatmap_color = cv2.applyColorMap(heatmap_norm, cv2.COLORMAP_JET)
#     overlay = cv2.addWeighted(img, 0.6, heatmap_color, 0.4, 0)
#     cv2.imwrite(out_path, overlay)
#     return out_path

# # ---------------- Face Detection ----------------
# def detect_faces(img_path, out_dir, base):
#     """
#     Detect faces, crop them, save cropped images,
#     and draw bounding boxes on the original.
#     """
#     img = cv2.imread(img_path)
#     if img is None:
#         return [], 0, None

#     gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
#     face_cascade = cv2.CascadeClassifier(CASCADE)
#     rects = face_cascade.detectMultiScale(gray, 1.1, 5, minSize=(30, 30))

#     faces_out = []
#     for i, (x, y, w, h) in enumerate(rects):
#         # Save cropped face
#         face_crop = img[y:y + h, x:x + w]
#         face_path = os.path.join(out_dir, f"{base}_face_{i+1}.jpg")
#         cv2.imwrite(face_path, face_crop)
#         faces_out.append({"crop": "/outputs/" + os.path.basename(face_path)})

#         # Draw bounding box on original
#         cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2)

#     # Save annotated image with bounding boxes
#     boxed_path = os.path.join(out_dir, f"{base}_faces_boxed.jpg")
#     cv2.imwrite(boxed_path, img)

#     return faces_out, len(rects), boxed_path

# # ---------------- Main Pipeline ----------------
# def detect_image(img_path, out_dir="outputs"):
#     """Main detection pipeline: metrics + heatmap + faces."""
#     Path(out_dir).mkdir(parents=True, exist_ok=True)
#     base = os.path.splitext(os.path.basename(img_path))[0]

#     # Copy original uploaded image (thumbnail)
#     thumbnail_path = os.path.join(out_dir, os.path.basename(img_path))
#     if not os.path.exists(thumbnail_path):
#         shutil.copy(img_path, thumbnail_path)

#     # ---- Real Metrics ----
#     lap = compute_laplacian_var(img_path)
#     hf = high_freq_energy(img_path)

#     lap_norm = max(0.0, min(1.0, (lap - 30) / (2500 - 30)))
#     hf_norm = max(0.0, min(1.0, (hf - 10.0) / (10000.0 - 10.0)))

#     # Dummy AI probability (replace with model later)
#     ai_prob = 0.76

#     # Weighted fusion
#     score = float(0.65 * ai_prob + 0.2 * lap_norm + 0.15 * hf_norm)
#     explanation = "Combined AI model score with sharpness & high-frequency features."

#     # ---- Heatmap ----
#     heatmap_values = np.random.rand(20, 20)  # placeholder grid
#     heatmap_path = os.path.join(out_dir, f"{base}_heatmap.png")
#     save_heatmap(heatmap_values, heatmap_path)

#     overlay_path = os.path.join(out_dir, f"{base}_overlay.png")
#     overlay_heatmap_on_image(img_path, heatmap_values, overlay_path)

#     # ---- Face Detection ----
#     faces, face_count, boxed_path = detect_faces(img_path, out_dir, base)

#     # ---- Return Structured Result ----
#     return {
#         "thumbnail": "/outputs/" + os.path.basename(thumbnail_path),
#         "ai_prob": ai_prob,
#         "score": score,
#         "sharpness": float(lap),
#         "high_freq_energy": float(hf),
#         "face_count": face_count,
#         "faces": faces,  # ✅ cropped face image paths
#         "faces_boxed": "/outputs/" + os.path.basename(boxed_path) if boxed_path else None,
#         "explanation": explanation,
#         "heatmap_image": "/outputs/" + os.path.basename(heatmap_path),
#         "heatmap_overlay": "/outputs/" + os.path.basename(overlay_path)
#     }

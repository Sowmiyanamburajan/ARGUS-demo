import cv2, os, numpy as np
from pathlib import Path
from scipy.signal import butter, filtfilt, welch

def sample_frames_center(video_path, out_dir, fps=4, max_frames=120, size=224):
    """Extract center-cropped frames for analysis"""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    cap = cv2.VideoCapture(video_path)
    total_fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
    step = max(1, int(total_fps // fps))
    frames, saved, i = [], 0, 0

    while True:
        ret, frame = cap.read()
        if not ret:
            break
        if i % step == 0:
            h, w = frame.shape[:2]
            side = min(h, w)
            cy, cx = h // 2, w // 2
            y1, x1 = max(0, cy - side // 2), max(0, cx - side // 2)
            crop = frame[y1:y1 + side, x1:x1 + side]
            crop = cv2.resize(crop, (size, size))
            frames.append(crop)
            saved += 1
            if saved >= max_frames:
                break
        i += 1
    cap.release()
    return frames

def extract_mean_green(frames):
    """Mean green channel for rPPG analysis"""
    return np.array([float(frame[:, :, 1].mean()) for frame in frames if frame is not None])

def rppg_authenticity(greens, fs=4.0):
    if len(greens) < 8:
        return {'score': 0.0, 'peak_freq': None}
    f, P = welch(greens, fs=fs, nperseg=min(256, len(greens)))
    idx = np.argmax(P)
    peak = float(f[idx])
    score = 1.0 if 0.7 <= peak <= 3.5 else max(0.0, 1 - abs(peak-1.5)/3.0)
    return {'score': score, 'peak_freq': peak}

def analyze_video_quality(frames):
    """Sharpness, motion blur, compression artifacts"""
    if not frames:
        return {'sharpness': 0.0, 'motion_blur': 0.0, 'compression_artifacts': 0.0}

    sharpness_scores, motion_scores = [], []

    for i, frame in enumerate(frames):
        if frame is None:
            continue
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        sharpness_scores.append(cv2.Laplacian(gray, cv2.CV_64F).var())
        if i > 0 and frames[i-1] is not None:
            prev_gray = cv2.cvtColor(frames[i-1], cv2.COLOR_BGR2GRAY)
            motion_scores.append(np.mean(cv2.absdiff(gray, prev_gray)))

    avg_sharpness = np.mean(sharpness_scores) if sharpness_scores else 0.0
    avg_motion = np.mean(motion_scores) if motion_scores else 0.0
    return {
        'sharpness': float(min(1.0, avg_sharpness / 500.0)),
        'motion_blur': float(1.0 - min(1.0, avg_motion / 50.0)),
        'compression_artifacts': float(1.0 - min(1.0, avg_sharpness / 500.0))
    }

def detect_deepfake_indicators(frames):
    """Check temporal face consistency & lighting"""
    if not frames or len(frames) < 2:
        return {'deepfake_prob': 0.5, 'indicators': []}
    indicators, scores = [], []

    for i in range(1, len(frames)):
        if frames[i] is None or frames[i-1] is None:
            continue
        gray1, gray2 = cv2.cvtColor(frames[i-1], cv2.COLOR_BGR2GRAY), cv2.cvtColor(frames[i], cv2.COLOR_BGR2GRAY)
        similarity = 1.0 - (np.mean(cv2.absdiff(gray1, gray2)) / 255.0)
        scores.append(similarity)

    deepfake_score = 0.0
    if scores:
        avg_consistency = np.mean(scores)
        if avg_consistency < 0.7:
            indicators.append('inconsistent_face_features')
            deepfake_score += 0.3
        if np.std(scores) > 0.3:
            indicators.append('temporal_inconsistencies')
            deepfake_score += 0.2

    # lighting changes
    brightness_changes = [abs(np.mean(frames[i]) - np.mean(frames[i-1])) / 255.0 for i in range(1, len(frames))]
    if brightness_changes and np.mean(brightness_changes) > 0.2:
        indicators.append('unnatural_lighting_changes')
        deepfake_score += 0.2

    return {'deepfake_prob': float(min(0.95, max(0.05, deepfake_score))), 'indicators': indicators}

def detect_video(video_path, out_dir="outputs"):
    """Full video analysis with summary"""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    frames = sample_frames_center(video_path, out_dir)
    frame_count = len(frames)

    if not frames:
        return {
            'type': 'video',
            'score': 0.5,
            'ai_prob': 0.5,
            'explanation': 'No frames could be extracted from video',
            'summary': 'No summary available',
            'frame_scores': [],
            'frame_labels': []
        }

    # Per-frame sharpness analysis
    frame_scores, frame_labels = [], []
    for idx, frame in enumerate(frames):
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        score = min(1.0, cv2.Laplacian(gray, cv2.CV_64F).var() / 500.0)
        frame_scores.append(round(score, 2))
        frame_labels.append(f"F{idx+1}")

    # Overall analysis
    quality = analyze_video_quality(frames)
    deepfake = detect_deepfake_indicators(frames)
    rppg = rppg_authenticity(extract_mean_green(frames))

    authenticity_score = 0.25*quality['sharpness'] + 0.20*(1-quality['compression_artifacts']) + 0.25*rppg['score'] + 0.30*(1-deepfake['deepfake_prob'])
    ai_prob = 1.0 - authenticity_score

    # Explanation text
    explanation_parts = []
    if quality['sharpness'] > 0.7: explanation_parts.append("High video sharpness detected")
    if rppg['score'] > 0.7: explanation_parts.append("Natural physiological signals detected")
    if deepfake['deepfake_prob'] > 0.7: explanation_parts.append("Potential deepfake indicators found")
    if quality['compression_artifacts'] > 0.7: explanation_parts.append("Compression artifacts detected")
    explanation = ". ".join(explanation_parts) if explanation_parts else "Standard video analysis completed"

    # Summary text
    summary_parts = []
    if quality['sharpness'] > 0.7: summary_parts.append("Sharp video quality")
    if rppg['score'] > 0.7: summary_parts.append("Natural physiological signals detected")
    if deepfake['deepfake_prob'] > 0.7: summary_parts.append("Potential deepfake indicators found")
    summary = ". ".join(summary_parts) if summary_parts else "Video analysis completed"

    # Sample thumbnail
    thumbnail_path = out_dir / f"{Path(video_path).stem}_thumb.jpg"
    cv2.imwrite(str(thumbnail_path), frames[0])

    return {
        'type': 'video',
        'score': float(authenticity_score),
        'ai_prob': float(ai_prob),
        'frame_scores': frame_scores,
        'frame_labels': frame_labels,
        'explanation': explanation,
        'summary': summary,
        'rppg_score': rppg['score'],
        'rppg_peak_freq': rppg['peak_freq'],
        'deepfake_prob': deepfake['deepfake_prob'],
        'deepfake_indicators': deepfake['indicators'],
        'sharpness': quality['sharpness'],
        'motion_blur': quality['motion_blur'],
        'compression_artifacts': quality['compression_artifacts'],
        'frame_count': frame_count,
        'thumbnail': f"/outputs/{thumbnail_path.name}"
    }




# current
# import cv2, os, numpy as np
# from pathlib import Path
# from ..utils import save_plot
# import librosa
# from scipy.signal import butter, filtfilt, welch
# import tempfile

# def sample_frames_center(video_path, out_dir, fps=4, max_frames=120, size=224):
#     """Extract frames from video center for analysis"""
#     Path(out_dir).mkdir(parents=True, exist_ok=True)
#     cap = cv2.VideoCapture(video_path)
#     total_fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
#     step = max(1, int(total_fps//fps))
#     i = 0
#     saved = 0
#     frames = []
    
#     while True:
#         ret, frame = cap.read()
#         if not ret: 
#             break
#         if i % step == 0:
#             h, w = frame.shape[:2]
#             side = min(h, w)
#             cy, cx = h//2, w//2
#             y1 = max(0, cy-side//2)
#             x1 = max(0, cx-side//2)
#             crop = frame[y1:y1+side, x1:x1+side]
#             crop = cv2.resize(crop, (size, size))
#             frames.append(crop)
#             saved += 1
#             if saved >= max_frames: 
#                 break
#         i += 1
#     cap.release()
#     return frames, saved

# def extract_mean_green(frames):
#     """Extract mean green channel values for rPPG analysis"""
#     vals = []
#     for frame in frames:
#         if frame is not None:
#             vals.append(float(frame[:,:,1].mean()))
#     return np.array(vals)

# def bandpass_filter(x, fs=4.0, low=0.7, high=3.5, order=3):
#     """Apply bandpass filter for rPPG analysis"""
#     if len(x) < 4: 
#         return x
#     ny = 0.5 * fs
#     lowc, highc = low/ny, high/ny
#     b, a = butter(order, [lowc, highc], btype='band')
#     return filtfilt(b, a, x)

# def rppg_authenticity(greens, fs=4.0):
#     """Analyze rPPG (remote photoplethysmography) for authenticity"""
#     if len(greens) < 8: 
#         return {'score': 0.0, 'peak_freq': None}
#     f, P = welch(greens, fs=fs, nperseg=min(256, len(greens)))
#     idx = np.argmax(P)
#     peak = float(f[idx])
#     score = 1.0 if 0.7 <= peak <= 3.5 else max(0.0, 1 - abs(peak-1.5)/3.0)
#     return {'score': score, 'peak_freq': peak}

# def analyze_video_quality(frames):
#     """Analyze video quality indicators"""
#     if not frames:
#         return {'sharpness': 0.0, 'motion_blur': 0.0, 'compression_artifacts': 0.0}
    
#     sharpness_scores = []
#     motion_scores = []
    
#     for i, frame in enumerate(frames):
#         if frame is None:
#             continue
            
#         # Convert to grayscale
#         gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        
#         # Sharpness analysis
#         laplacian_var = cv2.Laplacian(gray, cv2.CV_64F).var()
#         sharpness_scores.append(laplacian_var)
        
#         # Motion analysis (compare with previous frame)
#         if i > 0 and frames[i-1] is not None:
#             prev_gray = cv2.cvtColor(frames[i-1], cv2.COLOR_BGR2GRAY)
#             diff = cv2.absdiff(gray, prev_gray)
#             motion_score = np.mean(diff)
#             motion_scores.append(motion_score)
    
#     avg_sharpness = np.mean(sharpness_scores) if sharpness_scores else 0.0
#     avg_motion = np.mean(motion_scores) if motion_scores else 0.0
    
#     # Normalize scores
#     sharpness_score = min(1.0, avg_sharpness / 500.0)
#     motion_score = min(1.0, avg_motion / 50.0)
    
#     return {
#         'sharpness': float(sharpness_score),
#         'motion_blur': float(1.0 - motion_score),
#         'compression_artifacts': float(1.0 - sharpness_score)
#     }

# def detect_deepfake_indicators(frames):
#     """Detect potential deepfake indicators in video frames"""
#     if not frames or len(frames) < 2:
#         return {'deepfake_prob': 0.5, 'indicators': []}
    
#     indicators = []
#     deepfake_score = 0.0
    
#     # Check for face consistency across frames
#     face_consistency_scores = []
#     for i in range(1, len(frames)):
#         if frames[i] is not None and frames[i-1] is not None:
#             # Simple face region comparison
#             gray1 = cv2.cvtColor(frames[i-1], cv2.COLOR_BGR2GRAY)
#             gray2 = cv2.cvtColor(frames[i], cv2.COLOR_BGR2GRAY)
            
#             # Calculate structural similarity
#             diff = cv2.absdiff(gray1, gray2)
#             similarity = 1.0 - (np.mean(diff) / 255.0)
#             face_consistency_scores.append(similarity)
    
#     if face_consistency_scores:
#         avg_consistency = np.mean(face_consistency_scores)
#         if avg_consistency < 0.7:  # Low consistency might indicate deepfake
#             indicators.append('inconsistent_face_features')
#             deepfake_score += 0.3
    
#     # Check for unnatural lighting changes
#     lighting_changes = []
#     for i in range(1, len(frames)):
#         if frames[i] is not None and frames[i-1] is not None:
#             brightness1 = np.mean(frames[i-1])
#             brightness2 = np.mean(frames[i])
#             change = abs(brightness2 - brightness1) / 255.0
#             lighting_changes.append(change)
    
#     if lighting_changes:
#         avg_lighting_change = np.mean(lighting_changes)
#         if avg_lighting_change > 0.2:  # High lighting variation
#             indicators.append('unnatural_lighting_changes')
#             deepfake_score += 0.2
    
#     # Check for temporal inconsistencies
#     if len(face_consistency_scores) > 5:
#         consistency_std = np.std(face_consistency_scores)
#         if consistency_std > 0.3:  # High variation in consistency
#             indicators.append('temporal_inconsistencies')
#             deepfake_score += 0.2
    
#     deepfake_prob = min(0.95, max(0.05, deepfake_score))
    
#     return {
#         'deepfake_prob': float(deepfake_prob),
#         'indicators': indicators
#     }

# def extract_audio_from_video(video_path, out_dir):
#     """Extract audio from video for analysis"""
#     try:
#         audio_path = os.path.join(out_dir, os.path.basename(video_path) + '.wav')
#         # Use ffmpeg to extract audio
#         os.system(f'ffmpeg -y -i "{video_path}" -ar 16000 -ac 1 -vn "{audio_path}" 2>/dev/null')
#         return audio_path
#     except Exception as e:
#         print(f"Error extracting audio: {e}")
#         return None

# def analyze_video_audio(audio_path):
#     """Analyze audio characteristics for authenticity"""
#     if not audio_path or not os.path.exists(audio_path):
#         return {'energy': 0.0, 'zcr': 0.0, 'spectral_centroid': 0.0, 'mfcc': []}
    
#     try:
#         y, sr = librosa.load(audio_path, sr=16000)
#         energy = float(np.mean(np.abs(y)))
#         zcr = float(np.mean(librosa.feature.zero_crossing_rate(y)))
#         spectral_centroid = float(np.mean(librosa.feature.spectral_centroid(y=y, sr=sr)))
#         mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13)
#         mfcc_mean = [float(np.mean(mfcc[i])) for i in range(13)]
        
#         return {
#             'energy': energy,
#             'zcr': zcr,
#             'spectral_centroid': spectral_centroid,
#             'mfcc': mfcc_mean
#         }
#     except Exception as e:
#         print(f"Error analyzing audio: {e}")
#         return {'energy': 0.0, 'zcr': 0.0, 'spectral_centroid': 0.0, 'mfcc': []}

# def detect_video(video_path, out_dir="outputs"):
#     """Enhanced video detection with comprehensive analysis"""
#     Path(out_dir).mkdir(parents=True, exist_ok=True)
    
#     try:
#         # Extract frames for analysis
#         frames, frame_count = sample_frames_center(video_path, out_dir, fps=4, max_frames=120, size=224)
        
#         if not frames:
#             return {
#                 'type': 'video',
#                 'score': 0.5,
#                 'ai_prob': 0.5,
#                 'explanation': 'No frames could be extracted from video',
#                 'error': 'frame_extraction_failed'
#             }
        
#         # Basic video analysis
#         frame_intensities = [frame.mean() for frame in frames if frame is not None]
#         intensity_variation = np.std(frame_intensities) if frame_intensities else 0.0
        
#         # Quality analysis
#         quality_analysis = analyze_video_quality(frames)
        
#         # Deepfake detection
#         deepfake_analysis = detect_deepfake_indicators(frames)
        
#         # rPPG analysis for authenticity
#         greens = extract_mean_green(frames)
#         rppg_analysis = rppg_authenticity(greens, fs=4.0)
        
#         # Audio analysis
#         audio_path = extract_audio_from_video(video_path, out_dir)
#         audio_analysis = analyze_video_audio(audio_path)
        
#         # Calculate overall authenticity score
#         # Lower score = more likely to be authentic
#         authenticity_factors = [
#             quality_analysis['sharpness'] * 0.25,
#             (1.0 - quality_analysis['compression_artifacts']) * 0.20,
#             rppg_analysis['score'] * 0.25,
#             (1.0 - deepfake_analysis['deepfake_prob']) * 0.30
#         ]
        
#         authenticity_score = sum(authenticity_factors)
#         ai_prob = 1.0 - authenticity_score
        
#         # Generate explanation
#         explanation_parts = []
#         if quality_analysis['sharpness'] > 0.7:
#             explanation_parts.append("High video sharpness detected")
#         if rppg_analysis['score'] > 0.7:
#             explanation_parts.append("Natural physiological signals detected")
#         if deepfake_analysis['deepfake_prob'] > 0.7:
#             explanation_parts.append("Potential deepfake indicators found")
#         if quality_analysis['compression_artifacts'] > 0.7:
#             explanation_parts.append("Compression artifacts detected")
        
#         explanation = ". ".join(explanation_parts) if explanation_parts else "Standard video analysis completed"
        
#         # Create visualizations
#         plot_path = os.path.join(out_dir, os.path.basename(video_path) + "_analysis.png")
#         try:
#             save_plot(frame_intensities, plot_path, "Video Frame Intensity Analysis")
#         except:
#             plot_path = None
        
#         # Sample frame for thumbnail
#         sample_frame_path = None
#         if frames:
#             sample_frame_path = os.path.join(out_dir, os.path.basename(video_path) + "_sample.jpg")
#             cv2.imwrite(sample_frame_path, frames[0])
        
#         return {
#             'type': 'video',
#             'score': float(authenticity_score),
#             'ai_prob': float(ai_prob),
#             'sharpness': quality_analysis['sharpness'],
#             'motion_blur': quality_analysis['motion_blur'],
#             'compression_artifacts': quality_analysis['compression_artifacts'],
#             'rppg_score': rppg_analysis['score'],
#             'rppg_peak_freq': rppg_analysis['peak_freq'],
#             'deepfake_prob': deepfake_analysis['deepfake_prob'],
#             'deepfake_indicators': deepfake_analysis['indicators'],
#             'audio_analysis': audio_analysis,
#             'frame_count': frame_count,
#             'intensity_variation': float(intensity_variation),
#             'plot': plot_path,
#             'sample_frame': sample_frame_path,
#             'explanation': explanation,
#             'thumbnail': f"/outputs/{os.path.basename(sample_frame_path)}" if sample_frame_path else None
#         }
        
#     except Exception as e:
#         print(f"Error in video detection: {e}")
#         return {
#             'type': 'video',
#             'score': 0.5,
#             'ai_prob': 0.5,
#             'explanation': f"Error analyzing video: {str(e)}",
#             'error': str(e)
#         }
